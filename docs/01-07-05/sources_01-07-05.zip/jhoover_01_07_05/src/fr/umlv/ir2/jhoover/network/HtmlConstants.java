/**
 * jHoover - UMLV IR2
 * UI Project
 */
package fr.umlv.ir2.jhoover.network;

/**
 * @author Romain Papuchon
 *
 */
public class HtmlConstants {
	public final static String TEXT_HTML = "text/html";
	public final static String SCHEME_AND_AUTHORITY_SEPARATOR = "://";
}
